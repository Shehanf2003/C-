﻿create table category
(
catID int primary key identity,
catName varchar(50)
)